"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var PostMapper = /** @class */ (function () {
    function PostMapper() {
    }
    PostMapper.prototype.transform = function (feeds) {
        return feeds.map(function (_a) {
            var title = _a.title, link = _a.link, creator = _a.creator, pubDate = _a.pubDate, description = _a.description, encodedContent = _a["content:encoded"], categories = _a.categories;
            return { title: title, link: link, creator: creator, pubDate: pubDate, description: unescape(description), encodedContent: encodedContent, categories: categories };
        });
    };
    return PostMapper;
}());
exports.PostMapper = PostMapper;
//# sourceMappingURL=PostMapper.js.map